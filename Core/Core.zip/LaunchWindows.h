﻿#pragma once

#include "Platform.h"

extern void GuardedMain();

i32 WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ char* pCmdLine, _In_ INT32 nCmdShow);
